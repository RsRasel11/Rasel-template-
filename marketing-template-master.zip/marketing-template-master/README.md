# marketing-template
Bootstrap website for a marketing agency

Demo at https://determined-lovelace-2a7006.netlify.com/

## Usage 
 ``` bash
 git clone
 ```
 * or download zip file

 * Open 
 ```index.html ```
 on browser

 All images courtesy of [undraw](www.undraw.co)
